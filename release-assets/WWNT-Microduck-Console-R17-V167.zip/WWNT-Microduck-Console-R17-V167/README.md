# WWNT Robotics · Microduck R17 V167 Console — User Guide

This console version is `1.0.167`; the bundled robot firmware is `1fa8438-feetech-ft6-control.43`; the official system baseline is `0.15.1`. The physical gamepad uses the native padd → robotd channel to control walking and roller models; four roller ONNX models are installed with the firmware.

Source repository: [microduck-WWrobot (WWNT Robotics · UnitClaw fork)](https://github.com/UnitClaw/microduck-WWrobot), forked upstream from [kissqy/Microduck-kissqy](https://github.com/kissqy/Microduck-kissqy) with original author attribution preserved. Links are also provided at the top of the web page and in the Windows launcher.

## Getting Started

1. Fully extract `WWNT-Microduck-Console-R17-V167.zip`. On Windows run `start.cmd`, on macOS run `start.command`; on Linux run `python3 console.py --dashboard --feetech --open`.
2. Connect to the Zero over SSH from the web page and confirm the console is `1.0.167` and the robot is running `control.43`. This build includes a newly compiled robotd, which must be reinstalled via "System Maintenance → Bundled Firmware"; both the desktop console and the Zero firmware must be updated.
3. Wait for robotd startup steps 1/4–4/4 to complete before confirming live feedback and the physical gamepad connection. A successful connection alone does not trigger motion.
4. If the service shows `commissioning`, click "Switch to Motion Mode" and wait for the four-step startup to finish. Calibration mode does not load motion policies.

## Physical Gamepad — Roller Operation

Install the rollers first, release the sticks, and hold the robot steady. Press Start once to HOME, wait for it to settle, then long-press ↑ for 3 s to switch to roller mode. After the model switch completes, press Start to enable the policy, then use the sticks or A.

| Action | Current behaviour |
| --- | --- |
| ↑ long-press 3 s | Toggle walk / roller mode; on entering roller, A defaults to crouch |
| ← long-press 2 s | In roller mode, toggle A between crouch / spin-in-place; requires stationary HOME and no running action |
| A | Run the current roller action; in walk mode, performs ground pick-up |
| Left stick forward/back | Symmetric gliding; roller mode does not use lateral translation |
| Right stick left/right | Adjust target heading; robotd uses the current IMU heading to compute the heading error the model needs |
| Start | First press HOME; afterwards toggles policy enabled, returning to HOME when disabled |

To switch A's action, release the sticks, wait for the current action to end, press Start to disable the policy and wait for the robot to return to HOME, then long-press ← for 2 s. After switching, press Start to enable the policy and press A to run. When a request is rejected, check the reason in the log, fix the condition, and retry.

Keys must be held for the full duration; each long-press sends only one switch request, and switching again requires releasing first. Roller mode and its actions are operated through the physical gamepad; the web page provides no dedicated roller switch button. Web input is automatically disabled while a physical gamepad is connected.

## Model Display and Execution Parameters

Below the gamepad, the left column shows models and advanced parameters, the right column shows the Chinese key description. Model state comes from the same configuration read; the stand-up model shows the physical L3 manual test entry and its conditions — the web L3 is a hint only and produces no input.

The four roller cards are titled "Swizzle / 对称滑行", "Crouch / 蹲下", "Spin / 原地转", and "Stand up / 倒地起身"; training rounds and installation status appear under each title.

| Roller model | Base scale | Head filter | Leg filter | Current entry |
| --- | --- | --- | --- | --- |
| Swizzle | 1.0 | 1.0 | 1.0 | Roller stick |
| Crouch | 0.8 | 0.5 | 0.7 | Roller A, 5 s period, end phase 0.7 |
| Spin | 1.0 | 1.0 | 1.0 | Roller A, 4 s period, end phase 0.7 |
| Stand up | 1.0 | 1.0 | 1.0 | Physical L3: roller mode, motion enabled, IMU fallen; 5 s manual test |

When loading each model, robotd reads the raw contract's `required_policy_settings` and applies scale and filters during inference; it restores the gliding model's own parameters after the action ends. The crouch deployment filter and the no-EMA training history are preserved separately; training contracts and weights are never rewritten. Voltage compensation and gain continue to read the existing configuration.

The roller stand-up package's actual checkpoint is 11000; the "10000" in the filename is not model metadata. The raw contract declares `manual_skill` and a zero command, with no Stand slot or duration. The current `[[policy.skill]]` configuration sets a 5 s manual test window — this is a test configuration, not a training contract parameter. Physical L3 (left stick press) reads the actual mode and fresh IMU before executing; it is accepted only in roller mode with policy enabled, HOME completed, no other action, and IMU confirming a fall. Standing, walking, HOME, relax, or stale IMU is rejected with a logged reason. Each press requests only once; holding or gamepad reconnect does not resend. Start cancels. The window ends by returning to the gliding model. LB retains the left-foot kick; web L3 only shows the description.

## Other Keys

| Key | Default action |
| --- | --- |
| X | Forward roll |
| RB | Right-foot kick |
| LB | Left-foot kick, 0.5 s single action |
| D-pad down | Sit/stand toggle |
| Y / B | Head / body posture modes |
| RT / LT | Beak and sound control |
| Select short-press release | Relax (torque off) |
| Select long-press 2 s | Sit, relax, and shut down the Zero |

There is currently no separate LB stand-up test. The combined Walk model handles walking hold and recovery. Existing valid custom key bindings saved on this machine are used as-is.

## Calibration and Settings

Installation preserves any existing valid local calibration and saved parameters on the Zero. To restore the bundled assembly calibration, use the user-confirmed configuration in the package: 15 joint directions of −1, neck ID 30 zero 2526, ID 31 zero 2228, head ID 33 zero 1599, and the bundled IMU calibration.

This bundled calibration comes from the user-provided `duck-10e4` assembly data. On a fresh Zero image without valid local calibration, "restore assembly calibration" in the install log refers to this bundled data. After swapping robots, calibration should be checked against the actual assembly of that robot.

The direction column in live feedback reads the locally saved calibration; it shows "—" when there is no valid data. Advanced parameters preserve the action scale; the model contract provides the servo P, and other configuration follows the local valid settings and the current contract.

## Camera and Connection

mediad runs constantly; video wakes on demand: clicking connect starts capture, the last video user's exit puts it to sleep, and multiple pages can be used simultaneously. Merely starting the system or opening the page does not continuously capture video.

A waiting state is shown when the first connection has not received complete feedback. Real SSH, service, or startup errors are logged with reasons; use "Export Startup Diagnostic" to save a read-only diagnostic. For gamepad pairing repair, follow the on-page prompts in A+HOME mode and complete pairing.

## Exiting

The console script may keep running after the browser tab is closed. Before replacing or deleting the extracted directory, press Ctrl+C in the launch terminal and wait for exit. Windows address and DPAPI password are stored in AppData; SSH shares the current console's credential flow.

## Verification Scope

robotd / padd have completed real ARM64 compilation; the current control core, IPC, padd, and roller scope passed 235 tests. The six actions and four roller ONNX models were loaded and ran first inference by the new ARM64 robotd in QEMU; the package manifest hashes and the console firmware import check passed.

Real Zero roller motion has not yet been verified in this build environment. The above results cover only the explicitly listed scope and do not imply the whole project passed; original build and test records are kept in `verification/v167/`.

## HD1910 Runtime Parameters

P continues to follow the current model contract, using the existing address 50 single-byte write and relax restore. When torque is explicitly applied, address 51 writes one byte D=0 and address 48 writes two little-endian bytes 1000 (E8 03); after relax, D and the limit are retained. HOME, gamepad, model, calibration, and control timeouts continue to follow the current flow.
