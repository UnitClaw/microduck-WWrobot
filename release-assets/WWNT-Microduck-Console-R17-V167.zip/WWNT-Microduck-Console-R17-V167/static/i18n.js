/* WWNT Robotics Console — lightweight runtime i18n (zh ↔ en).
 * The UI is authored in Chinese; when the user picks English we translate
 * text nodes and a few attributes at runtime via a dictionary + MutationObserver,
 * so dynamically injected strings are covered without refactoring every module.
 */
(function () {
  "use strict";
  var KEY = "wwnt-console-lang";
  var lang = localStorage.getItem(KEY) || "en"; // default English
  var isEn = lang === "en";

  // 中文 -> English dictionary.
  var dict = {
    // sidebar
    "工作空间": "Workspace",
    "总览": "Overview",
    "鸭子控制": "Duck Control",
    "舵机诊断": "Servo Diagnostics",
    "传感器": "Sensors",
    "摄像头": "Camera",
    "链路与系统日志": "Link & System Log",
    "录制与回放": "Recording & Replay",
    "适配版本": "Compatible Version",
    "运行版尚未识别": "Runtime version not yet identified",
    "等待数据源": "Waiting for data source",
    // header
    "我的 Microduck": "My Microduck",
    "硬件观测台": "Hardware Console",
    "★ GitHub 开源 ↗": "★ GitHub Open Source ↗",
    "等待第一帧": "Waiting for first frame",
    "↓ 导出记录": "↓ Export Recording",
    "正在连接": "Connecting",
    "◈ 本地中控": "◈ Local Console",
    "连接与数据说明": "Connection & data notes",
    // main heading
    "让每一个动作，都有据可查": "Every motion, accounted for",
    "实时姿态 · 传感器 · 执行器诊断": "Live pose · sensors · actuator diagnostics",
    // ssh form
    "SSH 地址": "SSH address",
    "SSH / sudo 密码": "SSH / sudo password",
    "已保存或免密可留空": "Leave blank if saved or passwordless",
    "连接": "Connect",
    "断开": "Disconnect",
    "填写地址和密码后连接": "Enter address and password to connect",
    "清除密码": "Clear password",
    // metrics
    "控制循环": "Control loop",
    "关节反馈": "Joint feedback",
    "舵机总线电压": "Servo bus voltage",
    "最高舵机温度": "Max servo temperature",
    "ZERO 温度": "ZERO temperature",
    "等待数据": "Waiting for data",
    "目标 50 Hz · 等待数据": "Target 50 Hz · waiting for data",
    "未知不等于离线": "Unknown is not offline",
    "舵机端实测 · 曲线 4–8 V": "Measured at servos · 4–8 V scale",
    "等待 robot.health": "Waiting for robot.health",
    "等待主板温度回读": "Waiting for board temperature readback",
    "CPU": "CPU",
    // sections
    "鸭子 3D 视图": "Duck 3D View",
    "头部视野": "Head View",
    "模拟手柄": "Virtual Gamepad",
    "IMU · 身体姿态": "IMU · Body Attitude",
    "ToF · 深度视野": "ToF · Depth View",
    "轨迹与系统": "Trajectory & System",
    "执行器 · 舵机诊断": "Actuators · Servo Diagnostics",
    "链路与安全状态": "Link & Safety Status",
    "系统日志": "System Log",
    "等待姿态": "Waiting for pose",
    "未连接": "Not connected",
    "等待": "Waiting",
    "估计值": "Estimated",
    "未知": "Unknown",
    // common buttons / labels
    "官方手柄接口": "Official gamepad interface",
    "等待服务": "Waiting for service",
    "实体按键映射": "Physical key mapping",
    "模拟手柄 · 实体按键映射": "Virtual gamepad · physical key mapping",
    "中文按键说明": "Key reference (中文)",
    "连接摄像头": "Connect camera",
    "断开摄像头": "Disconnect camera",
    "下载完整日志 ↓": "Download full log ↓",
    "复制显示": "Copy shown",
    "自动滚动": "Auto-scroll",
    "等待系统日志。": "Waiting for system log.",
    "尚无执行记录。": "No execution records yet.",
    "事件与原始报文": "Events & raw messages",
    "事件": "Events",
    "原始报文": "Raw messages",
    "连接事件将在这里出现": "Connection events will appear here",
    "完成": "Done",
    "关闭窗口": "Close",
    "保存摄像头地址": "Save camera address",
    "摄像头主机": "Camera host",
    "WebRTC 信令端口": "WebRTC signaling port",
    "连接和数据能力": "Connection & capabilities",
    "实际数据能力": "Actual data capabilities",
    "当前模式：": "Current mode: ",
    "等待回读": "Waiting for readback",
    "高级参数": "Advanced parameters",
    "连接与数据说明": "Connection & data notes",
    "下载检测记录": "Download inspection recording",
    "调试记录与回放": "Debug recording & replay",
    "打开此前导出的记录": "Open a previously exported recording",
    "播放 / 暂停": "Play / pause",
    "退出回放": "Exit replay",
    // footer
    "模型 © Pollen Robotics": "Model © Pollen Robotics",
    // dialogs / common status
    "等待第一帧": "Waiting for first frame",
    "已连接": "Connected",
    "已断开": "Disconnected",
    "连接中": "Connecting",
    "连接失败": "Connection failed",
    "实时": "Live",
    "离线": "Offline",
    "过期": "Stale",
    "标定模式": "Calibration mode",
    "运动模式": "Motion mode",
    "台架模式": "Bench mode",
    "已启用": "Enabled",
    "未启用": "Disabled",
    "已标定": "Calibrated",
    "未标定": "Uncalibrated",
    "横滚 / Roll": "Roll",
    "俯仰 / Pitch": "Pitch",
    "融合就绪": "Fusion ready",
    "连续旧样本": "Consecutive stale samples",
    "重力 XYZ": "Gravity XYZ",
    "姿态未知": "Attitude unknown",
    "最近有效距离": "Nearest valid distance",
    "最远距离": "Farthest distance",
    "有效分区": "Valid regions",
    "尚无帧": "No frame yet",
    "等待测距服务连接与首帧数据。": "Waiting for ranging service and first frame.",
    "点击格子查看距离及状态": "Click a cell to view distance and status",
    "CPU 使用率": "CPU usage",
    "内存使用": "Memory usage",
    "Zero 温度": "Zero temperature",
    "Zero 开机时长": "Zero uptime",
    "最近 60 秒 · 单位向量": "Last 60 s · unit vector",
    "冻结版未导出": "Not exported in frozen build",
    "头部摄像头": "Head camera",
    "等待连接": "Waiting for connection",
    "LIVE CAMERA": "LIVE CAMERA",
    "帧率": "Frame rate",
    "码率": "Bitrate",
    "丢包累计": "Cumulative loss",
    "旋转": "Rotation",
    "全部关节": "All joints",
    "左腿": "Left leg",
    "头部": "Head",
    "右腿": "Right leg",
    "搜索 ID / 关节": "Search ID / joint",
    "实际角度 °": "Actual angle °",
    "目标 °": "Target °",
    "误差 °": "Error °",
    "速度 rpm": "Speed rpm",
    "电流 mA": "Current mA",
    "温度 °C": "Temperature °C",
    "电压 V": "Voltage V",
    "电流占限值 % ⓘ": "Current vs limit % ⓘ",
    "PWM %": "PWM %",
    "扭矩 / 故障": "Torque / fault",
    "反馈状态": "Feedback status",
    "关节 / ID": "Joint / ID",
    "选中关节可联动 3D 模型高亮": "Selected joint highlights in the 3D model",
    "实际角度 / 目标角度": "Actual angle / target angle",
    "电流 mA": "Current mA",
    "温度 °C": "Temperature °C",
    "速度 rpm": "Speed rpm",
    "跟随误差 °": "Following error °",
    "左髋旋转 · ID 20": "Left hip rotation · ID 20",
    "实测角度": "Measured angle",
    "目标角度": "Target angle",
    "查看选中舵机的寄存器详情": "View register details of selected servo",
    "台架只读模式提供": "Provided in bench read-only mode",
    "等待官方健康响应。": "Waiting for official health response.",
    "请求速度 · m/s, rad/s": "Requested velocity · m/s, rad/s",
    "实际采用速度": "Actual applied velocity",
    "没有收到状态前，不判断安全限制。": "Safety limits are not assessed before status is received.",
    "等待中控日志": "Waiting for console log",
    // misc
    "启动": "Startup",
    "操作结果与失败原因": "Operation results and failure reasons",
    "默认显示启动四步": "Default shows four startup steps"
  };

  function translateTextNode(node) {
    var s = node.nodeValue;
    if (!s) return;
    var t = s.trim();
    if (t && dict[t]) {
      node.nodeValue = s.replace(t, dict[t]);
    }
  }

  function translateAttr(node, attr) {
    var v = node.getAttribute && node.getAttribute(attr);
    if (v && dict[v]) node.setAttribute(attr, dict[v]);
  }

  function walk(node) {
    if (node.nodeType === 3) { translateTextNode(node); return; }
    if (node.nodeType !== 1) return;
    var tag = node.tagName;
    if (tag === "SCRIPT" || tag === "STYLE" || tag === "CODE") return;
    translateAttr(node, "title");
    translateAttr(node, "placeholder");
    translateAttr(node, "aria-label");
    var kids = node.childNodes;
    for (var i = 0; i < kids.length; i++) walk(kids[i]);
  }

  function applyEnglish() {
    document.documentElement.lang = "en";
    walk(document.body);
  }

  window.wwntSetLang = function (l) {
    localStorage.setItem(KEY, l);
    location.reload();
  };

  window.wwntToggleLang = function () {
    var cur = localStorage.getItem(KEY) || "en";
    window.wwntSetLang(cur === "en" ? "zh" : "en");
  };

  if (isEn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        applyEnglish();
        new MutationObserver(function (muts) {
          for (var i = 0; i < muts.length; i++) {
            var added = muts[i].addedNodes;
            for (var j = 0; j < added.length; j++) walk(added[j]);
          }
        }).observe(document.body, { childList: true, subtree: true });
      });
    } else {
      applyEnglish();
    }
  }

  // Keep the toggle label in sync with the current language.
  document.addEventListener("DOMContentLoaded", function () {
    var b = document.getElementById("lang-toggle");
    if (b) b.textContent = isEn ? "中文" : "EN";
  });
})();
