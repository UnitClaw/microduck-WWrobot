# Fake IMU ·「保存安装确认」断电丢失 — 根因与修复说明

> 适用：Microduck R17 系列（robotd 固件 `1fa8438-feetech-ft6-control.43`）。本文档由万物拟态（WWNT Robotics）整理，用于澄清圈内口口相传的「Fake IMU」问题。

## 1. 症状

- 网页「系统维护」里点击 **保存安装确认**（verify-imu）后，当前上电会话内 `imu_mount_verified = true` 生效、状态显示已确认；
- **断电重启后丢失**，又回到「未确认」；
- 同一页面里舵机标定（Capture）保存**正常**，重启后仍在。

## 2. 根因（已定位到源码）

旧版 robotd 固件中，`BusCommand::VerifyImu` 命令只更新了**内存中的** `Calibration` 结构：

```rust
updated.imu_mount_verified = true;
updated.motion_enabled = false;
// 旧版缺少下面这一行 —— 没有落盘
```

而舵机标定的 `Capture` 命令正确调用了 `save_calibration()`。这正好解释「舵机保存正常、IMU 断电丢失」：一个写盘、一个只改内存。

## 3. 修复（已存在于当前源码）

`firmware/robotd/src/feetech_commissioning.rs`（L588–618）的 `VerifyImu` 分支**已经**调用落盘：

```rust
updated.imu_mount_verified = true;
updated.motion_enabled = false;
save_calibration(path, &updated).map(|()| {
    *calibration = updated;
    calibration_status(calibration, path)
})
```

`save_calibration()`（L284–320）为原子写盘：先写临时文件 → `fsync` → `rename` → 目录 `fsync`，同时写 `hd1910-calibration.toml` 与 `.saved.toml` 双副本，改动前备份到 `previous.toml`。

启动时 `run()`（L825）用 `read_calibration()` 从磁盘加载，路径为：

```
/etc/robot/feetech-ft5/hd1910-calibration.toml
```

## 4. R17 V167 二进制是否已含修复

据随包 `BUILD.json` 构建元数据：

- `rebuilt_binaries: ["robotd"]` —— 本版 robotd 已重新编译；
- `native_production_changes: ["duck-control/src/hd1910.rs", "robotd/src/feetech_commissioning.rs: build identity"]` —— 相对上一版 V164，`feetech_commissioning.rs` **仅改了 BUILD 版本字符串**，即落盘逻辑在 V164 就已存在。

**结论**：R17 V167 的 robotd 二进制应已包含修复。圈内仍在传的「Fake IMU」标签与资料站「手动写 `imu_mount.toml`」是**老固件**的遗留对策（老固件用的是 `imu_mount.toml`，本 R17 已改用 `hd1910-calibration.toml`）。

## 5. 实机验证步骤（建议做一次落盘验证）

1. 装好 R17 固件，网页连接 Zero 并点「保存安装确认」；
2. 通过 SSH 查看磁盘标定文件：

   ```bash
   sudo cat /etc/robot/feetech-ft5/hd1910-calibration.toml
   ```

   确认 `imu_mount_verified = true` 且 `imu_mount_quat = [w, x, y, z]` 为归一化四元数；
3. 断电重启，再次 `cat` 同一文件，确认 `imu_mount_verified` **仍为 `true`**。

## 6. 若仍丢失（兜底）

说明手上的 robotd 是修复前的旧构建，需从已修复源码重编译并重新打包固件：

- 工具链：Rust 1.99.0 / cargo-zigbuild 0.23.4 / Zig 0.15.1
- 目标：`aarch64-unknown-linux-gnu.2.31`
- 源码：`microduck-hd1910/firmware/robotd`（`feetech_commissioning.rs` 已含修复）

## 7. 「Fake IMU」标签的由来

kissqy 在线 Demo 标 `source: Fake IMU`，是因为浏览器 Demo 无法运行真实硬件、只能用伪造 IMU 数据演示界面，与「落盘 bug」是两回事；但它让「Fake IMU」成为圈内对 IMU 相关问题的统称，容易与真正的落盘问题混为一谈。
