# Fake IMU — "Save Mount Confirmation" Lost After Power Cycle: Root Cause & Fix

> Applies to the Microduck R17 series (robotd firmware `1fa8438-feetech-ft6-control.43`). Maintained by WWNT Robotics (万物拟态) to clarify the "Fake IMU" issue circulating in the community.

## 1. Symptom

- After clicking **Save Mount Confirmation** (verify-imu) in the web console, `imu_mount_verified = true` takes effect in the current powered session and the status shows "confirmed";
- **It is lost after a power cycle**, reverting to "unconfirmed";
- On the same page, servo calibration (Capture) saves **correctly** and survives reboot.

## 2. Root Cause (located in source)

In older robotd firmware, the `BusCommand::VerifyImu` command only updated the **in-memory** `Calibration` struct:

```rust
updated.imu_mount_verified = true;
updated.motion_enabled = false;
// Older builds were missing the line below — no disk write
```

Servo calibration (`Capture`), by contrast, correctly called `save_calibration()`. This is exactly why "servo save works, IMU is lost on power-off": one writes to disk, the other only mutates memory.

## 3. Fix (already present in current source)

In `firmware/robotd/src/feetech_commissioning.rs` (L588–618), the `VerifyImu` branch **already** persists to disk:

```rust
updated.imu_mount_verified = true;
updated.motion_enabled = false;
save_calibration(path, &updated).map(|()| {
    *calibration = updated;
    calibration_status(calibration, path)
})
```

`save_calibration()` (L284–320) performs an atomic write: write temp file → `fsync` → `rename` → directory `fsync`, writing both `hd1910-calibration.toml` and `.saved.toml`, with the previous file backed up to `previous.toml`.

At startup, `run()` (L825) loads from disk via `read_calibration()`, from:

```
/etc/robot/feetech-ft5/hd1910-calibration.toml
```

## 4. Does the R17 V167 binary include the fix?

Per the bundled `BUILD.json` build metadata:

- `rebuilt_binaries: ["robotd"]` — robotd was recompiled for this release;
- `native_production_changes: ["duck-control/src/hd1910.rs", "robotd/src/feetech_commissioning.rs: build identity"]` — relative to the previous V164, `feetech_commissioning.rs` **only changed the BUILD version string**, meaning the persist logic already existed in V164.

**Conclusion**: the R17 V167 robotd binary should already include the fix. The "Fake IMU" label still circulating and the docs-site workaround of "manually writing `imu_mount.toml`" are leftovers from **older firmware** (which used `imu_mount.toml`; this R17 uses `hd1910-calibration.toml`).

## 5. On-device Verification (recommended)

1. Install the R17 firmware, connect to the Zero from the web console, and click "Save Mount Confirmation";
2. Over SSH, inspect the calibration file:

   ```bash
   sudo cat /etc/robot/feetech-ft5/hd1910-calibration.toml
   ```

   Confirm `imu_mount_verified = true` and `imu_mount_quat = [w, x, y, z]` is a normalized quaternion;
3. Power-cycle, then `cat` the same file again and confirm `imu_mount_verified` is **still `true`**.

## 6. Fallback if it is still lost

The robotd in hand is a pre-fix build; recompile from the fixed source and repackage the firmware:

- Toolchain: Rust 1.99.0 / cargo-zigbuild 0.23.4 / Zig 0.15.1
- Target: `aarch64-unknown-linux-gnu.2.31`
- Source: `microduck-hd1910/firmware/robotd` (`feetech_commissioning.rs` already contains the fix)

## 7. Where the "Fake IMU" label comes from

The kissqy online demo is tagged `source: Fake IMU` because a browser demo cannot run real hardware and must use fabricated IMU data for the UI — a separate matter from the persist bug. That tag nonetheless made "Fake IMU" the community shorthand for IMU-related issues, which is easily conflated with the actual persist problem.
